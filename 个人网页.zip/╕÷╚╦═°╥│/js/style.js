var btns = document.getElementsByClassName('goTop fas fa-arrow-up');
btns.onclick = function() {
    console.log('777');
}